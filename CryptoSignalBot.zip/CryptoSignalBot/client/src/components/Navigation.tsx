
import { memo } from "react";

const Navigation = memo(() => {
  const handleCTAClick = () => {
    window.open("https://t.me/+ZZYyFG_u8iUyMDIy", "_blank", "noopener,noreferrer");
  };

  return (
    <nav className="fixed top-0 w-full bg-gray-900/95 backdrop-blur-sm border-b border-gray-800 z-50 py-3 sm:py-4">
      <div className="container max-w-6xl mx-auto px-4">
        <div className="flex justify-between items-center">
          <div className="font-bold text-lg sm:text-xl text-cyan-400">
            <span className="hidden sm:inline">Крипто в тапках 🩴</span>
            <span className="sm:hidden">Крипто 🩴</span>
          </div>
          <button
            onClick={handleCTAClick}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-semibold py-2 px-4 sm:py-3 sm:px-6 rounded-full transition-all duration-300 text-sm sm:text-base min-h-[44px] min-w-[100px]"
          >
            <span className="hidden sm:inline">📱 Подписаться</span>
            <span className="sm:hidden">📱</span>
          </button>
        </div>
      </div>
    </nav>
  );
});

Navigation.displayName = "Navigation";

export default Navigation;
