
import { memo } from "react";

const TradingBot = memo(() => {
  const features = [
    "Готовые торговые сигналы",
    "Анализ точек входа и выхода",
    "Расчет риск/профит соотношения",
    "Уведомления в реальном времени"
  ];

  return (
    <section className="py-16 px-4 bg-gray-900/50">
      <div className="container max-w-4xl mx-auto text-center">
        <div className="text-5xl mb-6">🤖</div>
        <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">
          Бонус для подписчиков: <span className="text-blue-400">торговый бот</span>
        </h2>
        <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          Получайте готовые торговые сигналы с анализом входов, стопов и целей.
        </p>

        <div className="bg-gray-800/50 p-6 sm:p-8 rounded-lg border border-gray-700 mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3 text-left">
                <div className="text-green-400 text-xl">✓</div>
                <span className="text-sm sm:text-base text-gray-300">{feature}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-r from-blue-900/50 to-cyan-900/50 p-6 rounded-lg border border-blue-700/50">
          <div className="text-orange-400 font-bold text-lg mb-2">Бесплатно для подписчиков</div>
          <p className="text-gray-300 text-sm sm:text-base">
            Подпишитесь на канал и получите доступ к боту с торговыми сигналами.
          </p>
        </div>
      </div>
    </section>
  );
});

TradingBot.displayName = "TradingBot";

export default TradingBot;
