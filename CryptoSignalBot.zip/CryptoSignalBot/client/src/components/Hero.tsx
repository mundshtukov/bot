import { memo } from "react";

const Hero = memo(() => {
  const handleCTAClick = () => {
    window.open("https://t.me/+ZZYyFG_u8iUyMDIy", "_blank", "noopener,noreferrer");
  };

  return (
    <section className="min-h-screen flex items-center justify-center pt-16 pb-8 px-4">
      <div className="container max-w-4xl mx-auto text-center">
        <div className="mb-8">
          <div className="text-6xl sm:text-8xl mb-6">🚀</div>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
            Telegram-канал <span className="text-cyan-400">"Крипто в тапках"</span>
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-gray-300 mb-8 max-w-3xl mx-auto">
            Честная аналитика крипторынка без пафоса и лишних обещаний.
            <br />
            <span className="text-cyan-400">Бонус:</span> торговый бот с сигналами для подписчиков!
          </p>
        </div>

        <button
          onClick={handleCTAClick}
          className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold py-4 px-8 sm:py-5 sm:px-10 text-lg sm:text-xl rounded-full transition-all duration-300 hover:scale-105 shadow-lg min-h-[56px] w-full sm:w-auto"
        >
          📱 Подписаться на канал бесплатно
        </button>

        <div className="mt-12 grid grid-cols-3 gap-4 max-w-md mx-auto">
          <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
            <div className="text-2xl sm:text-3xl font-bold text-cyan-400 mb-1">0%</div>
            <div className="text-xs sm:text-sm text-gray-400 uppercase">пафоса</div>
          </div>
          <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
            <div className="text-2xl sm:text-3xl font-bold text-cyan-400 mb-1">100%</div>
            <div className="text-xs sm:text-sm text-gray-400 uppercase">честности</div>
          </div>
          <div className="bg-gray-800/50 p-4 rounded-lg border border-gray-700">
            <div className="text-2xl sm:text-3xl font-bold text-cyan-400 mb-1">∞</div>
            <div className="text-xs sm:text-sm text-gray-400 uppercase">иронии</div>
          </div>
        </div>
      </div>
    </section>
  );
});

Hero.displayName = "Hero";

export default Hero;