import { memo } from "react";

const Solutions = memo(() => {
  const solutions = [
    {
      icon: "📊",
      title: "Ежедневная аналитика рынка",
      description: "Разборы движений криптовалют простым языком. Без воды и сложных терминов."
    },
    {
      icon: "🎯",
      title: "Торговые сигналы от бота",
      description: "Готовые точки входа и выхода с расчетом рисков. Бесплатно для подписчиков."
    },
    {
      icon: "🧠",
      title: "Обучающие материалы",
      description: "Учим анализировать рынок самостоятельно, а не слепо следовать чужим советам."
    },
    {
      icon: "🛡️",
      title: "Защита от ловушек",
      description: "Предупреждаем об опасных движениях и помогаем избежать типичных ошибок новичков."
    }
  ];

  return (
    <section className="py-16 px-4">
      <div className="container max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">
            Что получают <span className="text-green-400">подписчики</span>
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Ежедневная аналитика рынка, обучающие материалы и торговые сигналы.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {solutions.map((solution, index) => (
            <div key={index} className="bg-gray-800/50 p-6 rounded-lg border border-gray-700 relative hover:bg-gray-800/70 transition-colors">
              <div className="absolute top-4 right-4">
                <span className="bg-orange-500 text-white px-3 py-1 rounded-full text-xs font-bold uppercase">
                  {solution.highlight}
                </span>
              </div>

              <div className="text-4xl mb-4">{solution.icon}</div>
              <h3 className="font-bold text-lg mb-3 text-cyan-400">
                {solution.title}
              </h3>
              <p className="text-gray-300 text-sm sm:text-base leading-relaxed pr-16">
                {solution.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

Solutions.displayName = "Solutions";

export default Solutions;