
import { memo } from "react";

const Problems = memo(() => {
  const problems = [
    {
      icon: "💸",
      title: "Потери от FOMO",
      description: "Покупаете на хайпе и теряете деньги на эмоциях"
    },
    {
      icon: "🤔",
      title: "Непонятная аналитика",
      description: "Сложные графики и термины вместо простых советов"
    },
    {
      icon: "⏰",
      title: "Пропуск сигналов",
      description: "Важные моменты для входа/выхода случаются без вас"
    },
    {
      icon: "😵",
      title: "Информационный шум",
      description: "Тонны противоречивых мнений и 'экспертов'"
    }
  ];

  return (
    <section className="py-16 px-4 bg-gray-900/50">
      <div className="container max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4">
            Знакомые <span className="text-red-400">проблемы</span>?
          </h2>
          <p className="text-lg sm:text-xl text-gray-300 max-w-2xl mx-auto">
            95% трейдеров сливают деньги по одним и тем же причинам
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {problems.map((problem, index) => (
            <div key={index} className="bg-gray-800/50 p-6 rounded-lg border border-gray-700 text-center hover:bg-gray-800/70 transition-colors">
              <div className="text-4xl mb-4">{problem.icon}</div>
              <h3 className="font-bold text-lg mb-3 text-cyan-400">
                {problem.title}
              </h3>
              <p className="text-gray-300 text-sm sm:text-base leading-relaxed">
                {problem.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

Problems.displayName = "Problems";

export default Problems;
