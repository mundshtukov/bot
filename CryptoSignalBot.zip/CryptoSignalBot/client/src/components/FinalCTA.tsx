
import { memo } from "react";

const FinalCTA = memo(() => {
  const handleCTAClick = () => {
    window.open("https://t.me/+ZZYyFG_u8iUyMDIy", "_blank", "noopener,noreferrer");
  };

  const benefits = [
    "Аналитика крипторынка каждый день",
    "Торговые сигналы от бесплатного бота",
    "Разборы успешных и неудачных сделок",
    "Обучение анализу без воды и пафоса"
  ];

  return (
    <section className="py-16 px-4 bg-gradient-to-br from-cyan-900/20 to-blue-900/20">
      <div className="container max-w-4xl mx-auto text-center">
        <div className="bg-gray-800/50 p-8 rounded-lg border border-gray-700">
          <div className="text-4xl mb-6">🎯</div>
          
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-6">
            Присоединяйтесь к <span className="text-cyan-400">"Крипто в тапках"</span>
          </h2>
          
          <p className="text-lg sm:text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
            Telegram-канал для тех, кто хочет разбираться в крипте, а не гадать на кофейной гуще
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8 max-w-2xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-3 text-left bg-gray-900/50 p-3 rounded-lg">
                <div className="text-green-400 text-xl">✓</div>
                <span className="text-sm sm:text-base text-gray-300">{benefit}</span>
              </div>
            ))}
          </div>

          <button
            onClick={handleCTAClick}
            className="bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white font-bold py-5 px-10 text-xl rounded-full transition-all duration-300 hover:scale-105 shadow-lg min-h-[64px] w-full sm:w-auto"
          >
            🚀 Подписаться на канал бесплатно
          </button>
        </div>
      </div>
    </section>
  );
});

FinalCTA.displayName = "FinalCTA";

export default FinalCTA;
