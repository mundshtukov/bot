import { memo, Suspense } from "react";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import Problems from "@/components/Problems";
import Solutions from "@/components/Solutions";
import TradingBot from "@/components/TradingBot";
import FinalCTA from "@/components/FinalCTA";

const Landing = memo(() => {
  return (
    <div className="min-h-screen bg-background text-foreground antialiased">
      <Navigation />
      <main>
        <Hero />
        <Suspense fallback={<div className="h-96 flex items-center justify-center"><div className="text-2xl">🚀</div></div>}>
          <Problems />
          <Solutions />
          <TradingBot />
          <FinalCTA />
        </Suspense>
      </main>
    </div>
  );
});

Landing.displayName = "Landing";

export default Landing;
